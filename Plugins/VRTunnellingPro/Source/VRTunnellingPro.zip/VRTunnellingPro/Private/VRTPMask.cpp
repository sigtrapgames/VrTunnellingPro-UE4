// Copyright 2021 Darby Costello. All Rights Reserved.
#include "VRTPMask.h"

UVRTPMask::UVRTPMask()
{
	PrimaryComponentTick.bCanEverTick = false;
}


// Called when the game starts
void UVRTPMask::BeginPlay()
{
	Super::BeginPlay();
}
